
# Shooter Boi

A top down action packed shooter game with modern pixel art graphics currentely under development.


![Screenshot](https://i.ibb.co/D9G7yF3/Screenshot-from-2023-08-28-22-00-36.png)


#### Gameplay on Ubuntu 20.04.3 64 bit x86-64.
 