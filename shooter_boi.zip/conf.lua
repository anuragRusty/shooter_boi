function love.conf(t)
    t.window.title = "Shooter Boi"
    t.window.width = 800;
    t.window.height = 600;
    --t.window.fullscreen = true;  
end